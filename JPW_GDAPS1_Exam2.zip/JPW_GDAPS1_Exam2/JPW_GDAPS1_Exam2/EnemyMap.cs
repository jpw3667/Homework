﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JPW_GDAPS1_Exam2
{
    class EnemyMap
    {
        private Tile[] map;

        //Creates a new map with the target density as the average density of enimies.
        public EnemyMap(double targetDensity)
        {
            map = new Tile[75];
            Random rng = new Random();
            for (int i = 0; i < map.Length; i++)
            {
                bool hasEnemy = rng.NextDouble() < targetDensity;
                map[i] = new Tile(hasEnemy);
            }
        }

        //Calculates the actual enemy density be dividing the total number of enemies by the total number of tiles on the map.
        public double EnemyDensity
        {
            get
            {
                double totalEnemies = 0;
                for (int i = 0; i < map.Length; i++)
                {
                    if (map[i].HasEnemy)
                    {
                        totalEnemies++;
                    }
                }
                return (totalEnemies / map.Length);
            }
        }

        //Displays every location on the map using the WriteTile method from the Tile class
        public void Display()
        {
            foreach(Tile t in map)
            {
                t.WriteTile();
            }
            Console.WriteLine("");
        }
    }
}
